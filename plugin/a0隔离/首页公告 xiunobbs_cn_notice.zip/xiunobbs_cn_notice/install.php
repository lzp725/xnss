<?php
!defined('DEBUG') AND exit('Forbidden');
$kv['content'] = 'Xiuno BBS站长交流论坛';
$kv['style'] = 'alert-success';
kv_set('xiunobbs_cn_notice', $kv);
?>