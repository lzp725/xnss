
case 'bbs': include APP_PATH.'plugin/meyan_theme_bbs/overwrite/view/htm/bbs.htm'; break;
