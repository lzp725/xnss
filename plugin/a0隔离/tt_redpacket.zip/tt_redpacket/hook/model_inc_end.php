include _include(APP_PATH.'plugin/tt_redpacket/model/redpacket.func.php');
