
	thread_digest_delete($tid, $uid, $fid);