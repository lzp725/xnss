<?php exit;
$sky_video_play_url = param('sky_video_play_url');
if($sky_video_play_url) {
    kv_set('sky_video_url_'.$tid, $sky_video_play_url);
}
?>