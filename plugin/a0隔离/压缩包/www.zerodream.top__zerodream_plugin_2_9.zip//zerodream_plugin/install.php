<?php

/*
    Powered by ZeroDream
    Optimized by ZeroDream
	https://www.zerodream.top/xiuno.htm
	
	修改文件将有禁止使用帐户风险
*/

 !defined('DEBUG') AND exit('Access Denied.'); function install_db() { global $db; $tablepre = $db->tablepre; $sql = "CREATE TABLE IF NOT EXISTS {$tablepre}zerodream_kv (
        k char(32) NOT NULL default '',
        v mediumtext NOT NULL,
        expiry int(11) unsigned NOT NULL default '0',
        PRIMARY KEY(k)
    ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci"; $r = db_exec($sql); $r === FALSE AND message(-1, '创建 zerodream_kv 表结构失败'); } function install_data() { $zd_kv_zerodream_plugin = zd_kv_get('zerodream_plugin'); $init = array( 'init' => false, 'key' => '', 'interface' => 'zerodream', 'node' => array( 'request_url' => 'zerodream', ), 'local_plugin' => array( 'zerodream_admin' => 1, 'search_plugin' => 1, 'new_upload_plugin' => 1, ), '_zd_plugin_data' => array(), ); $zd_kv_zerodream_plugin = zd_array_init($zd_kv_zerodream_plugin, $init, true); zd_kv_set('zerodream_plugin', $zd_kv_zerodream_plugin); $filename_arr = array( APP_PATH.'data/', APP_PATH.'data/zerodream_plugin/', APP_PATH.'data/zerodream_plugin/backup/', APP_PATH.'data/zerodream_plugin/cache/', APP_PATH.'data/zerodream_plugin/check/', APP_PATH.'data/zerodream_plugin/download/', APP_PATH.'data/zerodream_plugin/synchronous/', APP_PATH.'data/zerodream_plugin/tmp/', ); foreach($filename_arr as $filename) if(!is_dir($filename)) mkdir($filename); $filename_arr = array( APP_PATH.'data/zerodream_plugin/url_record.php', APP_PATH.'data/zerodream_plugin/zd_key_value.php', ); foreach($filename_arr as $filename) if(!is_file($filename)) zd_file_php_json_put($filename, ''); } function install_init() { $explode = explode('/', ADMIN_PATH); $count = count($explode); $admin = $explode[$count-2]; $oldname = APP_PATH.'plugin/zerodream_plugin/overwrite/admin'; $newname = APP_PATH."plugin/zerodream_plugin/overwrite/$admin"; rename($oldname, $newname); } function install_rmdir() { global $conf; rmdir_recusive($conf['tmp_path'], 1); } if(!defined('DEFINED_ZERODREAM_PLUGIN_ZERODREAM_FUNCTION')) include _include(APP_PATH.'plugin/zerodream_plugin/model/zerodream.func.php'); install_db(); install_data(); install_init(); install_rmdir(); ?>