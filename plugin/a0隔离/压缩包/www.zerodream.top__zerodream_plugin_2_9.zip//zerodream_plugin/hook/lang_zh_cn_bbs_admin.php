<?php exit;

/*
    Powered by ZeroDream
    Optimized by ZeroDream
	https://www.zerodream.top/xiuno.htm
	
	修改文件将有禁止使用帐户风险
*/

 'admin_plugin_zd_plugin_list' => '本地插件', 'admin_plugin_zerodream_plugin_plugin' => '零梦插件', 'admin_plugin_zerodream_plugin_template' => '零梦模板', 'admin_plugin_zerodream_plugin_cloud' => '零梦云端', 'admin_plugin_help' => '帮助', 'admin_plugin_brief_url' => '介绍网址', 'admin_plugin_download_successful'=>'下载成功', 'admin_plugin_install_successful'=>'安装成功', 'admin_plugin_update_successful'=>'更新成功', ?>