<?php exit;

/*
    Powered by ZeroDream
    Optimized by ZeroDream
	https://www.zerodream.top/xiuno.htm
	
	修改文件将有禁止使用帐户风险
*/

 !defined('DEBUG') AND exit('Access Denied.'); define('_URL_REWRITE_ON', ''); define('_ZERODREAM_URL', 'https://www.zerodream.top/'); define('_ZERODREAM_URL_THREAD', _ZERODREAM_URL._URL_REWRITE_ON.'thread-'); define('_ZERODREAM_URL_XIUNO', _ZERODREAM_URL._URL_REWRITE_ON.'xiuno.htm'); define('_ZD_PLUGIN_API_VERSION', '1_0'); define('_ZD_PLUGIN_API_URL_VERSION', 'zd_plugin_api_'._ZD_PLUGIN_API_VERSION); define('ZD_SEPARATOR', '<zd_br>'); $zd_url_rewrite_on = $conf['url_rewrite_on']; if(isset($_SERVER['HTTPS']) && strcasecmp($_SERVER['HTTPS'],'on')==0) $zd_scheme = 'https'; elseif(isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strcasecmp($_SERVER['HTTP_X_FORWARDED_PROTO'],'https')==0) $zd_scheme = 'https'; else $zd_scheme = 'http'; $zd_host = $_SERVER['HTTP_HOST']; $zd_scheme_host = "$zd_scheme://$zd_host/"; $zd_kv_zerodream_plugin = zd_kv_get('zerodream_plugin'); $request_url = $zd_kv_zerodream_plugin['node']['request_url']; if($request_url=='zerodream') $zd_plugin_request_type = 'zerodream'; else $zd_plugin_request_type = 'other'; $_SERVER['zd_data']['url_rewrite_on'] = $zd_url_rewrite_on; $_SERVER['zd_data']['scheme'] = $zd_scheme; $_SERVER['zd_data']['host'] = $zd_host; $_SERVER['zd_data']['scheme_host'] = $zd_scheme_host; $_SERVER['zd_data']['zd_plugin_request_type'] = $zd_plugin_request_type; ?>