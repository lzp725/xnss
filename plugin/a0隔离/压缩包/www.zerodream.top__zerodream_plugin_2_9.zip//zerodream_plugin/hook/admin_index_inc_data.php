<?php exit;

/*
    Powered by ZeroDream
    Optimized by ZeroDream
	https://www.zerodream.top/xiuno.htm
	
	修改文件将有禁止使用帐户风险
*/

 define('ROUTE_ADMIN', true); include _include(APP_PATH.'plugin/zerodream_plugin/admin/model/_zd_plugin.func.php'); $zd_kv_zerodream_plugin = zd_kv_get('zerodream_plugin'); $interface = $zd_kv_zerodream_plugin['interface']; if($interface=='zerodream') $menu = include APP_PATH.'plugin/zerodream_plugin/conf/menu.conf.php'; $zd_plugin_read_wait = param('zd_plugin_read_wait'); if($zd_plugin_read_wait) { $_zd_kv = _zd_kv_get('zerodream_plugin'); $_zd_kv['read_wait'] = $zd_plugin_read_wait; _zd_kv_put('zerodream_plugin', $_zd_kv); $zd_plugin_url_record = zd_plugin_url_record_get(); $zd_plugin_url_record['zd_plugin_information']['source'] = 'zd_plugin_thread_download'; zd_plugin_url_record_put($zd_plugin_url_record); } ?>