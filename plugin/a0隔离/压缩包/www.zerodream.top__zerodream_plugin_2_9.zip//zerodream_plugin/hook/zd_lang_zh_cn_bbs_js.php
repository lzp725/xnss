<?php exit;

/*
    Powered by ZeroDream
    Optimized by ZeroDream
	https://www.zerodream.top/xiuno.htm
	
	修改文件将有禁止使用帐户风险
*/

 lang['zd_alert_subject'] = '提示'; lang['zd_confirm_subject'] = '确认信息'; ?>