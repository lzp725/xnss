<?php 
	exit;
	include _include(APP_PATH.'plugin/xiunobbs_cn_list_block/htm/forum.htm');exit;
?>