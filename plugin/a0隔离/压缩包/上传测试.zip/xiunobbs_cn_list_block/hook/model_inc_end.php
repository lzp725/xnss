
	include _include(APP_PATH.'plugin/xiunobbs_cn_list_block/model/list.fun.php');

