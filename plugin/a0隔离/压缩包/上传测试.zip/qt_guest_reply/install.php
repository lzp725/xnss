<?php

/*
	Xiuno BBS 4.0 插件：游客回帖安装
	admin/plugin-install-qt_guest_reply.htm
*/

!defined('DEBUG') AND exit('Forbidden');

?>