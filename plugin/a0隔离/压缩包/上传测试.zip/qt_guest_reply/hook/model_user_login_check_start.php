<?php exit;
global $route;
$action = param(1,'');
if($route == 'post' and $action == 'create') return true;
