$beishu=file_get_contents(APP_PATH.'plugin/dayu2017_xuni/hook/beishu.htm');
$n=ceil($n*$beishu);