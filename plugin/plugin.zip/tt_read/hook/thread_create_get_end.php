<?php exit;
$pnumber=0;
$input['readp_status'] = form_radio_yes_no('readp_status', 0);
?>