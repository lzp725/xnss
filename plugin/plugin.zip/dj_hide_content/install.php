<?php
/**
 * @author 于磊 <86683712@qq.com>
*/
defined('DEBUG') OR exit('Forbidden');

// 添加配置
setting_set('dj_gids', '1'); 
?>