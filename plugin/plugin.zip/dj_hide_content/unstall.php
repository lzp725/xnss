<?php
/**
 * @author 于磊 <86683712@qq.com>
*/
!defined('DEBUG') AND exit('Forbidden');

// 删除插件配置
setting_delete('dj_gids');
